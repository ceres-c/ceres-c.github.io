						.~=> rEFInd Theme for Surface Pro 3 <=~.

// Installation:

	Copy the surface-theme folder into your refind directory (or Microsoft/Boot directory
	if you are hijacking the Windows bootloader on your Surface) and add the following line
	to your refind.conf:
	
		include surface-theme/theme.conf
		
	...then reboot and enjoy!
	
// For SP1/2
	
	You'll need to change the resolution of the bootloader in the theme.conf and probably
	downscale the icons for it to look right on the smaller screens. You should be able to
	resize the icons in the theme.conf too without having to actually edit the image files.
	
// About:

	If you have any issues or icon requests then hit me up on reddit at /u/frebib
	I'd be happy to help you.
	
	The icons in this theme were adapted from this theme on Deviantart: 
	http://sdbinwiiexe.deviantart.com/art/rEFInd-Next-Theme-407754566
	
	I have included all of the PSDs from the icons I created so feel free to adapt and do
	whatever with them, I really don't care!